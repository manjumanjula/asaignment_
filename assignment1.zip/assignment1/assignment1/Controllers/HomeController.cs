﻿using assignment1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace assignment1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

       public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpGet]
        public IActionResult Index()
        {
            var model = new MyModel
            {
                Title = "Welcome",
                Content = "This is a partial view example."
            };

            return View(model);
        }

        [HttpPost]
        public IActionResult Index(MyModel model)
        {
            // Handle the form submission here
            return View(model);
        }
    }
}
