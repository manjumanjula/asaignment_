﻿namespace assignment1.Models
{
  
        public class MyModel
        {
            public string Title { get; set; }
            public string Content { get; set; }
        }
    }
